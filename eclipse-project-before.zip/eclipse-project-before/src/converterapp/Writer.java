package converterapp;

public interface Writer {
	public void write(String toWrite);
	public void closeWriteWork();
}
